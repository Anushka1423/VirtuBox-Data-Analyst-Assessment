import pandas as pd

# Load both datasets
orders = pd.read_csv("List of Orders.csv")
details = pd.read_csv("Order Details.csv")

# Merge using Order ID
df = pd.merge(
    orders,
    details,
    on="Order ID",
    how="inner"
)

# Show the result
print("Merged dataset shape:", df.shape)

print("\nColumns:")
print(df.columns)

print("\nFirst 5 rows:")
print(df.head())

# Save merged dataset
df.to_csv("merged_ecommerce_data.csv", index=False)

print("\nMerged dataset saved successfully!")