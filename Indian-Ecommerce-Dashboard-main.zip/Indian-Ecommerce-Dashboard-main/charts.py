import pandas as pd
import plotly.express as px

# Load cleaned data
df = pd.read_csv("cleaned_orders.csv")

# Count orders by state
state_counts = df['state'].value_counts().reset_index()
state_counts.columns = ['state', 'orders']

# Create bar chart
fig = px.bar(
    state_counts,
    x='state',
    y='orders',
    title='Orders by State'
)

fig.show()