import pandas as pd

# Load dataset
df = pd.read_csv("List of Orders.csv")

# Clean column names
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Remove completely empty rows
df = df.dropna(how='all')

# Remove rows with missing values
df = df.dropna()

# Remove duplicates
df = df.drop_duplicates()

# Save cleaned file
df.to_csv("cleaned_orders.csv", index=False)

print("Final Shape:", df.shape)
print("Cleaning completed successfully!")