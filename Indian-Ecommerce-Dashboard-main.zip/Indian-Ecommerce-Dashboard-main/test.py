import pandas as pd

orders = pd.read_csv("List of Orders.csv")

print(orders.head())