import pandas as pd
df = pd.read_csv('Order Details.csv')
print(df.head())
print(df.columns)