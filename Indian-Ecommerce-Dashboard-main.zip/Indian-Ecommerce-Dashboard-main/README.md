# 🛒 Indian E-commerce Dashboard
An interactive sales analytics dashboard built using **Python, Pandas, Plotly, and Streamlit** to analyze Indian e-commerce order and sales data.

## 🚀 Live Dashboard

🔗 https://indian-ecommerce-dashboard-yk4ra5a8fbv6ky9ddukz78.streamlit.app/

## 📂 GitHub Repository

🔗 https://github.com/Anushka1423/Indian-Ecommerce-Dashboard

## 📊 Features

- KPI Cards (Total Sales, Profit, Quantity, Profit Margin)
- Orders by State
- Sales by Category
- Profit by Category
- Monthly Sales Trend
- Top 10 Sub-Categories by Sales
- Top 5 States Share
- Interactive State Filter
- Dataset Preview

## 🛠️ Technologies Used

- Python
- Pandas
- Plotly Express
- Streamlit
- Git & GitHub

## 📈 Key Insights

- **Electronics** generated the highest sales.
- **Clothing** produced the highest profit.
- **Furniture** showed lower profitability despite substantial sales volume.
- The overall **profit margin was approximately 5.55%**.

## ▶️ Run Locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 📸 Dashboard Preview

<img width="1917" height="962" alt="Screenshot 2026-08-12 174946" src="https://github.com/user-attachments/assets/6e27fe67-db4b-44b2-9caf-fa72be02fe28" />
<img width="1919" height="976" alt="Screenshot 2026-08-12 175143" src="https://github.com/user-attachments/assets/b3228f0f-9786-43df-956e-4a1902598c35" />
<img width="1918" height="800" alt="Screenshot 2026-08-12 175133" src="https://github.com/user-attachments/assets/900454ba-793d-4688-b198-8262cb07651b" />
<img width="1919" height="925" alt="Screenshot 2026-08-12 175117" src="https://github.com/user-attachments/assets/9ac8361a-18e3-4bee-90e8-cb9d66f86681" />
<img width="1919" height="973" alt="Screenshot 2026-08-12 175050" src="https://github.com/user-attachments/assets/2bb4aae0-1f81-451c-996d-39b8d87a6d47" />

---

Built with ❤️ by **Anushka Singhal**
