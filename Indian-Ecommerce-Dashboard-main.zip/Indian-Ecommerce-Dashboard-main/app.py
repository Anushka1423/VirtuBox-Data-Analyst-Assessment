import streamlit as st
import pandas as pd
import plotly.express as px

# Page Config
st.set_page_config(
    page_title="Indian E-commerce Dashboard",
    page_icon="🛒",
    layout="wide"
)

# Title
st.title("🛒 Indian E-commerce Dashboard")

st.markdown(
    "### 📊 Interactive sales and profitability insights for an Indian e-commerce business"
)

# Load Data
df = pd.read_csv("merged_ecommerce_data.csv")

# Clean column names
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Sidebar Filter
selected_state = st.sidebar.selectbox(
    "Select State",
    ["All"] + sorted(df["state"].unique().tolist())
)

# Apply Filter
if selected_state != "All":
    filtered_df = df[df["state"] == selected_state]
else:
    filtered_df = df

# ================= KPI SECTION =================

st.markdown("### 📈 Real-time Order Insights Across Indian States")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Total Sales",
        f"₹{filtered_df['amount'].sum():,.0f}"
    )

with col2:
    st.metric(
        "Total Profit",
        f"₹{filtered_df['profit'].sum():,.0f}"
    )

with col3:
    st.metric(
        "Total Quantity",
        f"{filtered_df['quantity'].sum():,}"
    )

with col4:
    profit_margin = (
        filtered_df["profit"].sum()
        / filtered_df["amount"].sum()
    ) * 100

    st.metric(
        "Profit Margin",
        f"{profit_margin:.2f}%"
    )

st.markdown("---")

# ================= CHART DATA =================

# Orders by State
state_counts = (
    filtered_df["state"]
    .value_counts()
    .reset_index()
)

state_counts.columns = ["state", "orders"]

state_fig = px.bar(
    state_counts,
    x="state",
    y="orders",
    title="Orders by State",
    text="orders"
)

state_fig.update_layout(
    xaxis_title="State",
    yaxis_title="Number of Orders",
    xaxis_tickangle=-35,
    height=500
)

# Sales by Category
category_sales = (
    filtered_df.groupby("category")["amount"]
    .sum()
    .reset_index()
)

category_fig = px.bar(
    category_sales,
    x="category",
    y="amount",
    title="Sales by Category",
    text="amount"
)

category_fig.update_layout(
    xaxis_title="Category",
    yaxis_title="Sales Amount (₹)"
)

# Profit by Category
category_profit = (
    filtered_df.groupby("category")["profit"]
    .sum()
    .reset_index()
)

profit_fig = px.bar(
    category_profit,
    x="category",
    y="profit",
    title="Profit by Category",
    text="profit"
)

profit_fig.update_layout(
    xaxis_title="Category",
    yaxis_title="Profit (₹)"
)

# Monthly Sales Trend
filtered_df["order_date"] = pd.to_datetime(
    filtered_df["order_date"],
    dayfirst=True
)

monthly_sales = (
    filtered_df.groupby(
        filtered_df["order_date"].dt.to_period("M")
    )["amount"]
    .sum()
    .reset_index()
)

monthly_sales["order_date"] = monthly_sales["order_date"].astype(str)

monthly_fig = px.line(
    monthly_sales,
    x="order_date",
    y="amount",
    title="Monthly Sales Trend",
    markers=True
)

monthly_fig.update_layout(
    xaxis_title="Month",
    yaxis_title="Sales (₹)"
)

# Top 10 Sub-Categories
subcategory_sales = (
    filtered_df.groupby("sub-category")["amount"]
    .sum()
    .sort_values(ascending=False)
    .head(10)
    .reset_index()
)

subcategory_fig = px.bar(
    subcategory_sales,
    x="amount",
    y="sub-category",
    title="Top 10 Sub-Categories by Sales",
    orientation="h",
    text="amount"
)

subcategory_fig.update_layout(
    xaxis_title="Sales (₹)",
    yaxis_title="Sub-Category"
)

# Top 5 States Pie Chart
top5 = state_counts.head(5)

pie_fig = px.pie(
    top5,
    names="state",
    values="orders",
    hole=0.4
)

# ================= DASHBOARD LAYOUT =================

# Row 1
left, right = st.columns(2)

with left:
    st.plotly_chart(
        state_fig,
        use_container_width=True
    )

with right:
    st.plotly_chart(
        category_fig,
        use_container_width=True
    )

st.markdown("---")

# Row 2
left, right = st.columns(2)

with left:
    st.plotly_chart(
        profit_fig,
        use_container_width=True
    )

with right:
    st.subheader("📊 Top 5 States Share")

    st.plotly_chart(
        pie_fig,
        use_container_width=True
    )

st.markdown("---")

# Row 3
st.plotly_chart(
    monthly_fig,
    use_container_width=True
)

st.markdown("---")

# Row 4
st.plotly_chart(
    subcategory_fig,
    use_container_width=True
)

st.markdown("---")

# ================= DATA PREVIEW =================

st.subheader("📋 Dataset Preview")

st.dataframe(filtered_df.head(10))

